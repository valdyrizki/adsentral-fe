// app/plugins/auth-init.client.ts

export default defineNuxtPlugin(async () => {


  const authStore = useAuthStore()
  const balanceStore = useBalanceStore()
  const config = useRuntimeConfig()


  // Kalau accessToken sudah ada (rare case: hot-reload atau navigasi internal), skip
  if (authStore.accessToken) {
    authStore.setInitialized()
    return
  }


  try {
    // 1. Panggil /refresh — browser auto-attach cookie refreshToken (HttpOnly)
    const response = await $fetch<{
      status: string
      data: { access_token: string }
    }>('/user/refresh', {
      method: 'POST',
      credentials: 'include',
      baseURL: config.public.apiBase as string,
    })

    const newAccessToken = response.data.access_token
    authStore.setAccessToken(newAccessToken)

    // 2. Fetch profile pakai access token baru
    //    Tidak bisa pakai useApi() di sini karena auth state belum stabil,
    //    jadi panggil $fetch manual dengan header eksplisit.
    const profileResponse = await $fetch<{
      status: string
      data: any  // sesuaikan dengan UserResponse / UserProfileResponse kamu
    }>('/user/profile', {
      method: 'GET',
      credentials: 'include',
      baseURL: config.public.apiBase as string,
      headers: {
        'X-API-TOKEN': newAccessToken,
      },
    })

    await balanceStore.loadBalance()
    authStore.setUser(profileResponse.data)
  } catch (err: any) {
    // Refresh gagal = user belum login atau refresh token expired
    // Diam saja — user akan lihat halaman dengan UI "Daftar/Masuk"
    // Jangan log error — ini case normal untuk visitor yang belum login
  } finally {
    authStore.setInitialized()  // ← selalu set true di akhir, sukses atau gagal
  }
})