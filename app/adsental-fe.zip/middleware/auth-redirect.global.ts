// app/middleware/auth-redirect.global.ts

export default defineNuxtRouteMiddleware(async (to) => {

  if (import.meta.server) {
    return
  }

  const authStore = useAuthStore()


  if (authStore.isInitializing) {
    await new Promise<void>((resolve) => {
      const stop = watch(
        () => authStore.isInitializing,
        (val) => {
          if (!val) {
            stop()
            resolve()
          }
        },
        { immediate: true }
      )
    })
  }

  const isAuthenticated = !!authStore.accessToken

  const guestOnlyRoutes = ['/login', '/register', '/forgot-password']
  const publicRoutes = [
    '/',
    '/product',
    '/category',
    '/search',
    '/merchant',
    ...guestOnlyRoutes,
  ]

  if (isAuthenticated && guestOnlyRoutes.includes(to.path)) {
    return navigateTo('/')
  }

  if (!isAuthenticated && !isPublicPath(to.path, publicRoutes)) {
    return navigateTo('/login')
  }

})

function isPublicPath(path: string, publicRoutes: string[]): boolean {
  return publicRoutes.some(route =>
    path === route || path.startsWith(route + '/')
  )
}