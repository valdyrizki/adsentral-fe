

<template>
  <div>
    <!-- HEADER -->
    <div>
      <!-- <AppHeader/> -->
      <AppHeader/>
    </div>
    
    <!-- MAIN/ -->
    <div>
      <slot/> 
    </div>

    <div class="mt-10">
      <AppFooter/>
    </div>

    <!-- Mount confirm dialog di root, biar bisa dipanggil dari mana saja -->
    <ConfirmDialog
      v-model="confirmState.isOpen"
      :title="confirmState.title"
      :message="confirmState.message"
      :confirm-text="confirmState.confirmText"
      :cancel-text="confirmState.cancelText"
      :confirm-color="confirmState.confirmColor"
      :loading="confirmState.loading"
      @confirm="onConfirm"
      @cancel="onCancel"
    />

  </div>
</template>

<script setup lang="ts">
import ConfirmDialog from '~/components/app/ConfirmDialog.vue'

const { state: confirmState, handleConfirm: onConfirm, handleCancel: onCancel } = useConfirm()
</script>





