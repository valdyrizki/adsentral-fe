export default defineAppConfig({
  ui: {
    colors: {
      primary: 'blue',
      secondary: 'yellow',
      tertiary: 'yellow',
    }
  }
})
