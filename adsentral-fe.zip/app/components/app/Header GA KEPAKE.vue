<!-- components/Header.vue -->
<template>
  <header>
    <div>
        <AppHeaderInfo/>
    </div>

    <div>
        <AppHeaderMain/>
    </div>
  </header>
</template>
