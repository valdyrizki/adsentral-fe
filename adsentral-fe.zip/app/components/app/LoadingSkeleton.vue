<template>
  <div>
    <!-- Skeleton saat loading -->
      <USkeleton class="h-10 w-full mb-2 rounded-lg bg-gray-300" />
      <USkeleton class="h-6 w-1/2 mb-2 rounded-lg bg-gray-300" />
      <USkeleton class="h-6 w-1/2 mb-2 rounded-lg bg-gray-300" />
  </div>
</template>

<script setup>
</script>
