<script setup lang="ts">

</script>

<template>
  <div>
    <!-- HEADER -->
    <div>
      <!-- <AppHeader/> -->
      <app-header-example/>
    </div>
    
    <!-- MAIN/ -->
    <div>
      <slot/> 
    </div>

    <div class="mt-10">
      <AppFooter/>
    </div>
  </div>
</template>;




