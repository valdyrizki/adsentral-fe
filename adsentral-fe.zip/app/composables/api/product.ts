import type { PageResponse } from "~/dto/PageResponse"
import type { ProductResponse } from "~/dto/ProductResponse"
import type { WebResponse } from "~/dto/WebResponse"

// composables/api/products.ts
export const useProductsApi = () => {
  const config = useRuntimeConfig()


  // GET products dengan pagination + search
  const getProducts = async (page = 0, size = 10, keyword = '') => {
    const { data, error } = await useFetch<WebResponse<PageResponse<ProductResponse[]>>>(`${config.public.apiBase}/products`, {
      method: 'GET',
      query: {
        page,
        size,
        keyword
      },
      key: `products-${page}-${size}-${keyword}`, // cache per request
    })

    //throw Error
    if (error.value) {
      throw createError({
        statusCode: error.value.statusCode,
        statusMessage: error.value.message || 'Failed to fetch products',
      })
    }

    //throw Error 2
    if(data.value?.status !== 'success'){
      throw createError({
        statusCode: 400,
        statusMessage: data.value?.message || 'Failed to fetch products',
      })
    }
    return data.value?.data
  }

  // GET products by category id
  const getProductsByCategoryId = async (id:number, page = 0, size = 10, keyword = '') => {
    const { data, error } = await useFetch<WebResponse<PageResponse<ProductResponse[]>>>(`${config.public.apiBase}/product/category/${id}`, {
      method: 'GET',
      query: {
        page,
        size,
        keyword
      },
      key: `products-by-category-${id}-${page}-${size}-${keyword}`, // cache per request
    })

    //throw Error
    if (error.value) {
      throw createError({
        statusCode: error.value.statusCode,
        statusMessage: error.value.message || 'Failed to fetch products',
      })
    }

    //throw Error 2
    if(data.value?.status !== 'success'){
      throw createError({
        statusCode: 400,
        statusMessage: data.value?.message || 'Failed to fetch products',
      })
    }
    return data.value?.data
  }

  return { getProducts, getProductsByCategoryId }
}
