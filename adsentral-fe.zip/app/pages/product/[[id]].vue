<template>
  <div>
    <h1>PRODUCT</h1>
  </div>
</template>

<script lang="ts" setup>

</script>

<style>

</style>