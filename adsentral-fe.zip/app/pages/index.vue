<template>
  <div class="bg-white">

    <div>
      <AppCategoryPreview/>
    </div>

    <div>
      <AppProductList/>
    </div>

  </div>
</template>

<script setup>
import { AppProductList } from '#components';


</script>